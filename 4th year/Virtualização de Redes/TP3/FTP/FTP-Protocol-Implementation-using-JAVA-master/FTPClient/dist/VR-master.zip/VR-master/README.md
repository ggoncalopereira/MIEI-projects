# VR
TP3 de VR

# Link sobre DNS:
https://www.digitalocean.com/community/tutorials/how-to-configure-bind-as-a-private-network-dns-server-on-ubuntu-14-04#configure-secondary-dns-server
